import React, { useState, useEffect } from "react"
import axios from "axios"
import MovieList from "./components/MovieList"
import SearchBar from "./components/SearchBar"
import "./App.css"

const API_KEY = "c25b8953acb580b6aed4f8bc6097cb8b"
const API_BASE_URL = "https://api.themoviedb.org/3"

function App() {
	const [movies, setMovies] = useState([])
	const [searchTerm, setSearchTerm] = useState("")
	const [error, setError] = useState(null)

	useEffect(() => {
		fetchMovies()
	}, [searchTerm])

	const fetchMovies = async () => {
		try {
			const endpoint = searchTerm
				? `${API_BASE_URL}/search/movie?api_key=${API_KEY}&query=${searchTerm}`
				: `${API_BASE_URL}/movie/popular?api_key=${API_KEY}`
			const response = await axios.get(endpoint)
			if (response.data.results.length === 0) {
				setError("No movies found for your search :(")
				setMovies([])
			} else {
				setMovies(response.data.results)
				setError(null)
			}
		} catch (error) {
			console.error("Error fetching movies:", error)
			setError("An error occurred while fetching movies.")
			setMovies([])
		}
	}

	const handleSearch = term => {
		setSearchTerm(term)
	}

	return (
		<div className='bg-filter'>
			<div className='App'>
				<h1>Movie Database</h1>
				<SearchBar onSearch={handleSearch} />
				{error ? (
					<p className='error-message'>{error}</p>
				) : (
					<MovieList movies={movies} />
				)}
			</div>
		</div>
	)
}

export default App
