import React, { useState } from "react"

function MovieCard({ movie, isFocused, isBlurred, onClick }) {
	const [isHovered, setIsHovered] = useState(false)

	const posterUrl = movie.poster_path
		? `https://image.tmdb.org/t/p/w500${movie.poster_path}`
		: "https://via.placeholder.com/500x750"

	const cardClassName = `movie-card ${isFocused ? "focused" : ""} ${
		isBlurred ? "blurred" : ""
	} ${isHovered ? "hovered" : ""}`

	return (
		<div
			className={cardClassName}
			onClick={onClick}
			onMouseEnter={() => setIsHovered(true)}
			onMouseLeave={() => setIsHovered(false)}>
			<img
				src={posterUrl}
				alt={movie.title}
			/>
			<h2 className='title'>{movie.title}</h2>
			<p className='release'>{movie.release_date}</p>
			<p className='rating'>{movie.vote_average}/10</p>
		</div>
	)
}

export default MovieCard
