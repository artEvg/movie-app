import React, { useState } from "react"
import MovieCard from "./MovieCard"

function MovieList({ movies }) {
	const [focusedCard, setFocusedCard] = useState(null)

	const handleCardClick = movieId => {
		setFocusedCard(focusedCard === movieId ? null : movieId)
	}

	const handleOverlayClick = () => {
		setFocusedCard(null)
	}

	return (
		<>
			<div
				className={`overlay ${focusedCard ? "active" : ""}`}
				onClick={handleOverlayClick}></div>
			<div className='movie-list'>
				{movies.map(movie => (
					<MovieCard
						key={movie.id}
						movie={movie}
						isFocused={focusedCard === movie.id}
						isBlurred={focusedCard !== null && focusedCard !== movie.id}
						onClick={() => handleCardClick(movie.id)}
					/>
				))}
			</div>
		</>
	)
}

export default MovieList
